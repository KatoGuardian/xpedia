1. Copy this to the root directory of the game.

2. If you have Node.js installed, regardless of OS, run "node xpedia.js". Otherwise, if you are using Windows, run "xpedia.bat".
It will construct and open xpedia.html. 
"node xpedia.js" option makes more compact file, is cross platform and is more flexible (for example, allows you to change intro text).

Or if you already has up-to-date xpedia.html you can just open it directly.

If mod is *not* XPiratez or language is not English, edit xpedia.bat (or xpedia.js) to change mod's name.

X-Piratez Bootypedia is a branch of Xpedia designed to use with X-Piratez mod.
In this offline version of Bootypedia not all its features are supported.
Please visit xpiratez.wtf website to take advantage of all the amenities of X-Piratez Bootypedia (tooltips and multilanguage support).